package com.banco_dev_week.banco_dev_week;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancoDevWeekApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancoDevWeekApplication.class, args);
	}

}
