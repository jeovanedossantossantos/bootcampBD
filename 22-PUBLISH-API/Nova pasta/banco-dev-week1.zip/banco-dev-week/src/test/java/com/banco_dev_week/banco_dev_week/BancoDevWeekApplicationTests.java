package com.banco_dev_week.banco_dev_week;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoDevWeekApplicationTests {

	@Test
	void contextLoads() {
	}

}
